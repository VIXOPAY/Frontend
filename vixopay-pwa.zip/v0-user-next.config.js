/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  images: {
    domains: ["placeholder.com"],
  },
  // Enable PWA features
  pwa: {
    dest: "public",
    register: true,
    skipWaiting: true,
  },
}

module.exports = nextConfig

